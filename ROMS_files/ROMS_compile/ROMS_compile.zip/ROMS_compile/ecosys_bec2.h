!
!  tracer: values passed to biological model by ROMS
!  DTRACER_MODULE: stores the tendencies of the biological tracers
!
      real tracer(GLOBAL_2D_ARRAY,N,ntrc_bio)
      real DTRACER_MODULE(GLOBAL_2D_ARRAY,N,ntrc_bio)
      common /tracers/ tracer, DTRACER_MODULE

#ifdef BEC2_DIAG
!
! Diagnostic variables appearing in average and history files:
!
      integer nr_bec2_diag_2d, nr_bec2_diag_3d, nr_bec2_diag

/* Still in BEC2 Diag now start counting for nr_bec2_diag_3d */
      parameter( nr_bec2_diag_3d=93
# ifdef EXPLICIT_MICROBES
#  ifdef HETERO_GRAZING
     &  +68
#  else
     &  +60
#  endif
#endif
     & , nr_bec2_diag_2d=29
# ifdef EXPLICIT_MICROBES
     &  +8
#endif
     &  )
      parameter( nr_bec2_diag=nr_bec2_diag_2d+nr_bec2_diag_3d )
# ifdef BEC2_DIAG_USER
      real, pointer, dimension(:,:,:,:) :: bec2_diag_3d
      real, pointer, dimension(:,:,:) :: bec2_diag_2d
      logical bec2_diag_3d_l(nr_bec2_diag_3d), bec2_diag_2d_l(nr_bec2_diag_2d)
      integer nr_bec2_diag_2d_user, nr_bec2_diag_3d_user
      integer bec2_diag_3d_idx(nr_bec2_diag_3d), bec2_diag_2d_idx(nr_bec2_diag_2d)
# else
      real bec2_diag_3d(GLOBAL_2D_ARRAY,N,nr_bec2_diag_3d)
      real bec2_diag_2d(GLOBAL_2D_ARRAY,nr_bec2_diag_2d)
# endif /* BEC2_DIAG_USER */

      common /bec2_diag1/ bec2_diag_2d, bec2_diag_3d
# ifdef BEC2_DIAG_USER
     &      , bec2_diag_3d_l, bec2_diag_2d_l, bec2_diag_3d_idx, bec2_diag_2d_idx
     &      , nr_bec2_diag_2d_user, nr_bec2_diag_3d_user
# endif

  ! MF: Control BEC2_DIAG Output vars
      logical wrtavg_bec2_diag_2d(nr_bec2_diag_2d)
      logical wrtavg_bec2_diag_3d(nr_bec2_diag_3d)

      common wrtavg_bec2_diag_2d, wrtavg_bec2_diag_3d

      ! Indices to be used in bec2_diag_3d only:
      integer, parameter :: par_idx_t=1,pocfluxin_idx_t=par_idx_t+1,
     &   pocprod_idx_t=par_idx_t+2,pocremin_idx_t=par_idx_t+3,caco3fluxin_idx_t=par_idx_t+4,
     &   pcaco3prod_idx_t=par_idx_t+5,caco3remin_idx_t=par_idx_t+6,sio2fluxin_idx_t=par_idx_t+7,
     &   sio2prod_idx_t=par_idx_t+8,sio2remin_idx_t=par_idx_t+9,dustfluxin_idx_t=par_idx_t+10,
     &   dustremin_idx_t=par_idx_t+11,pironfluxin_idx_t=par_idx_t+12,pironprod_idx_t=par_idx_t+13,
     &   pironremin_idx_t=par_idx_t+14,grazesp_idx_t=par_idx_t+15,grazediat_idx_t=par_idx_t+16,
     &   grazediaz_idx_t=par_idx_t+17,sploss_idx_t=par_idx_t+18,diatloss_idx_t=par_idx_t+19,
     &   zooloss_idx_t=par_idx_t+20,spagg_idx_t=par_idx_t+21,diatagg_idx_t=par_idx_t+22,
     &   photocsp_idx_t=par_idx_t+23,photocdiat_idx_t=par_idx_t+24,totprod_idx_t=par_idx_t+25,
     &   docprod_idx_t=par_idx_t+26,docremin_idx_t=par_idx_t+27,fescavenge_idx_t=par_idx_t+28,
     &   spnlim_idx_t=par_idx_t+29,spfeuptake_idx_t=par_idx_t+30,sppo4uptake_idx_t=par_idx_t+31,
     &   splightlim_idx_t=par_idx_t+32,diatnlim_idx_t=par_idx_t+33,diatfeuptake_idx_t=par_idx_t+34,
     &   diatpo4uptake_idx_t=par_idx_t+35,diatsio3uptake_idx_t=par_idx_t+36,diatlightlim_idx_t=par_idx_t+37,
     &   caco3prod_idx_t=par_idx_t+38,diaznfix_idx_t=par_idx_t+39,diazloss_idx_t=par_idx_t+40,
     &   photocdiaz_idx_t=par_idx_t+41,diazpo4uptake_idx_t=par_idx_t+42,diazfeuptake_idx_t=par_idx_t+43,
     &   diazlightlim_idx_t=par_idx_t+44,fescavengerate_idx_t=par_idx_t+45,donprod_idx_t=par_idx_t+46,
     &   donremin_idx_t=par_idx_t+47,dofeprod_idx_t=par_idx_t+48,doferemin_idx_t=par_idx_t+49,
     &   dopprod_idx_t=par_idx_t+50,dopremin_idx_t=par_idx_t+51,diatsiuptake_idx_t=par_idx_t+52,
     &   ironuptakesp_idx_t=par_idx_t+53,ironuptakediat_idx_t=par_idx_t+54,ironuptakediaz_idx_t=par_idx_t+55,
     &   nitrif_idx_t=par_idx_t+56,denitrif_idx_t=par_idx_t+57,spno3uptake_idx_t=par_idx_t+58,
     &   diatno3uptake_idx_t=par_idx_t+59,diazno3uptake_idx_t=par_idx_t+60,spnh4uptake_idx_t=par_idx_t+61,
     &   diatnh4uptake_idx_t=par_idx_t+62,diaznh4uptake_idx_t=par_idx_t+63,grazedicsp_idx_t=par_idx_t+64,
     &   grazedicdiat_idx_t=par_idx_t+65,grazedicdiaz_idx_t=par_idx_t+66,lossdicsp_idx_t=par_idx_t+67,
     &   lossdicdiat_idx_t=par_idx_t+68,lossdicdiaz_idx_t=par_idx_t+69,zoolossdic_idx_t=par_idx_t+70,
     &   diazagg_idx_t=par_idx_t+71,grazespzoo_idx_t=par_idx_t+72,grazediatzoo_idx_t=par_idx_t+73,
     &   grazediazzoo_idx_t=par_idx_t+74,spqcaco3_idx_t=par_idx_t+75,spphotoacc_idx_t=par_idx_t+76,
     &   diatphotoacc_idx_t=par_idx_t+77,diazphotoacc_idx_t=par_idx_t+78,spczero_idx_t=par_idx_t+79,
     &   diatczero_idx_t=par_idx_t+80,diazczero_idx_t=par_idx_t+81,doczero_idx_t=par_idx_t+82,
     &   zooczero_idx_t=par_idx_t+83,spcaco3zero_idx_t=par_idx_t+84,donrremin_idx_t=par_idx_t+85,
     &   totchl_idx_t=par_idx_t+86,
     &   spplim_idx_t=par_idx_t+87,diatplim_idx_t=par_idx_t+88,diazplim_idx_t=par_idx_t+89,
     &   totphytoc_idx_t=par_idx_t+90,o2cons_idx_t=par_idx_t+91, o2prod_idx_t=par_idx_t+92
#  undef LAST_I
#  define LAST_I o2prod_idx_t

# ifdef EXPLICIT_MICROBES
#  ifdef HETERO_GRAZING
      integer, parameter :: ammox_idx_t=LAST_I+1,nitrox_idx_t=LAST_I+2,
     &   anammox_idx_t=LAST_I+3,denitrif1_idx_t=LAST_I+4,denitrif2_idx_t=LAST_I+5,
     &   denitrif3_idx_t=LAST_I+6,spno2uptake_idx_t=LAST_I+7,
     &   diatno2uptake_idx_t=LAST_I+8,diazno2uptake_idx_t=LAST_I+9,
     &   n2oammox_idx_t=LAST_I+10,
     &   aoamu_idx_t=LAST_I+11,nobmu_idx_t=LAST_I+12,aoxmu_idx_t=LAST_I+13,
     &   aermu_idx_t=LAST_I+14,narmu_idx_t=LAST_I+15,naimu_idx_t=LAST_I+16,
     &   nirmu_idx_t=LAST_I+17,niomu_idx_t=LAST_I+18,nosmu_idx_t=LAST_I+19,naomu_idx_t=LAST_I+20,
     &   aoabio_idx_t=LAST_I+21,nobbio_idx_t=LAST_I+22,aoxbio_idx_t=LAST_I+23,
     &   aerbio_idx_t=LAST_I+24,narbio_idx_t=LAST_I+25,naibio_idx_t=LAST_I+26,
     &   nirbio_idx_t=LAST_I+27,niobio_idx_t=LAST_I+28,nosbio_idx_t=LAST_I+29,naobio_idx_t=LAST_I+30,
     &   aoagraze_idx_t=LAST_I+31,nobgraze_idx_t=LAST_I+32,aoxgraze_idx_t=LAST_I+33,
     &   aergraze_idx_t=LAST_I+34,nargraze_idx_t=LAST_I+35,naigraze_idx_t=LAST_I+36,
     &   nirgraze_idx_t=LAST_I+37,niograze_idx_t=LAST_I+38,nosgraze_idx_t=LAST_I+39,
     &   naograze_idx_t=LAST_I+40,
     &   aoaloss_idx_t=LAST_I+41,nobloss_idx_t=LAST_I+42,aoxloss_idx_t=LAST_I+43,
     &   aerloss_idx_t=LAST_I+44,narloss_idx_t=LAST_I+45,nailoss_idx_t=LAST_I+46,
     &   nirloss_idx_t=LAST_I+47,nioloss_idx_t=LAST_I+48,nosloss_idx_t=LAST_I+49,
     &   naoloss_idx_t=LAST_I+50,
     &   narana_idx_t=LAST_I+51,naiana_idx_t=LAST_I+52,nirana_idx_t=LAST_I+53,
     &   nioana_idx_t=LAST_I+54,nosana_idx_t=LAST_I+55,naoana_idx_t=LAST_I+56,
     &   dinrelease_idx_t=LAST_I+57,diprelease_idx_t=LAST_I+58,
     &   dinuptake_idx_t=LAST_I+59,dipuptake_idx_t=LAST_I+60,dfeuptake_idx_t=LAST_I+61,
     &   szooloss_idx_t=LAST_I+62,docrremin_idx_t=LAST_I+63,doprremin_idx_t=LAST_I+64,
     &   denitrif4_idx_t=LAST_I+65,denitrif5_idx_t=LAST_I+66,denitrif6_idx_t=LAST_I+67,
     &   no2ammox_idx_t=LAST_I+68
#  else
      integer, parameter :: ammox_idx_t=LAST_I+1,nitrox_idx_t=LAST_I+2,
     &   anammox_idx_t=LAST_I+3,denitrif1_idx_t=LAST_I+4,denitrif2_idx_t=LAST_I+5,
     &   denitrif3_idx_t=LAST_I+6,spno2uptake_idx_t=LAST_I+7,
     &   diatno2uptake_idx_t=LAST_I+8,diazno2uptake_idx_t=LAST_I+9,
     &   n2oammox_idx_t=LAST_I+10,
     &   aoamu_idx_t=LAST_I+11,nobmu_idx_t=LAST_I+12,aoxmu_idx_t=LAST_I+13,
     &   aermu_idx_t=LAST_I+14,narmu_idx_t=LAST_I+15,naimu_idx_t=LAST_I+16,
     &   nirmu_idx_t=LAST_I+17,niomu_idx_t=LAST_I+18,nosmu_idx_t=LAST_I+19,naomu_idx_t=LAST_I+20,
     &   aoabio_idx_t=LAST_I+21,nobbio_idx_t=LAST_I+22,aoxbio_idx_t=LAST_I+23,
     &   aerbio_idx_t=LAST_I+24,narbio_idx_t=LAST_I+25,naibio_idx_t=LAST_I+26,
     &   nirbio_idx_t=LAST_I+27,niobio_idx_t=LAST_I+28,nosbio_idx_t=LAST_I+29,naobio_idx_t=LAST_I+30,
     &   aoagraze_idx_t=LAST_I+31,nobgraze_idx_t=LAST_I+32,aoxgraze_idx_t=LAST_I+33,
     &   aoaloss_idx_t=LAST_I+34,nobloss_idx_t=LAST_I+35,aoxloss_idx_t=LAST_I+36,
     &   aerloss_idx_t=LAST_I+37,narloss_idx_t=LAST_I+38,nailoss_idx_t=LAST_I+39,
     &   nirloss_idx_t=LAST_I+40,nioloss_idx_t=LAST_I+41,nosloss_idx_t=LAST_I+42,
     &   naoloss_idx_t=LAST_I+43,
     &   narana_idx_t=LAST_I+44,naiana_idx_t=LAST_I+45,nirana_idx_t=LAST_I+46,
     &   nioana_idx_t=LAST_I+47,nosana_idx_t=LAST_I+48,naoana_idx_t=LAST_I+49,
     &   dinrelease_idx_t=LAST_I+50,diprelease_idx_t=LAST_I+51,
     &   dinuptake_idx_t=LAST_I+52,dipuptake_idx_t=LAST_I+53,dfeuptake_idx_t=LAST_I+54,
     &   docrremin_idx_t=LAST_I+55,doprremin_idx_t=LAST_I+56,
     &   denitrif4_idx_t=LAST_I+57,denitrif5_idx_t=LAST_I+58,denitrif6_idx_t=LAST_I+59,
     &   no2ammox_idx_t=LAST_I+60
#  endif
# undef LAST_I
# define LAST_I no2ammox_idx_t
# endif

      ! Indices to be used in bec2_diag_2d only:
      integer, parameter :: pco2air_idx_t=1,
     &   parinc_idx_t=pco2air_idx_t+1, fgo2_idx_t=pco2air_idx_t+2, fgco2_idx_t=pco2air_idx_t+3,
     &   ws10m_idx_t=pco2air_idx_t+4, xkw_idx_t=pco2air_idx_t+5, atmpress_idx_t=pco2air_idx_t+6,
     &   schmidto2_idx_t=pco2air_idx_t+7, o2sat_idx_t=pco2air_idx_t+8, schmidtco2_idx_t=pco2air_idx_t+9,
     &   pvo2_idx_t=pco2air_idx_t+10,pvco2_idx_t=pco2air_idx_t+11,ironflux_idx_t=pco2air_idx_t+12,
     &   seddenitrif_idx_t=pco2air_idx_t+13,ph_idx_t=pco2air_idx_t+14,pco2_idx_t=pco2air_idx_t+15,
     &   co2star_idx_t=pco2air_idx_t+16,pco2oc_idx_t=pco2air_idx_t+17,dco2star_idx_t=pco2air_idx_t+18
# undef LAST_I
# define LAST_I dco2star_idx_t
#ifdef EXPLICIT_MICROBES
     &   ,schmidt_n2o_idx_t=LAST_I+1, pvn2o_idx_t=LAST_I+2, n2osat_idx_t=LAST_I+3,
     &    fgn2o_idx_t=LAST_I+4, schmidt_n2_idx_t=LAST_I+5, pvn2_idx_t=LAST_I+6, 
     &    fgn2_idx_t=LAST_I+7, n2sat_idx_t=LAST_I+8
# undef LAST_I
# define LAST_I n2sat_idx_t
# endif
      integer, parameter :: fesedflux_idx_t=LAST_I+1,
     &   fluxtosed_idx_t=LAST_I+2,caco3fluxtosed_idx_t=LAST_I+3,
     &   sio2fluxtosed_idx_t=LAST_I+4,pironfluxtosed_idx_t=LAST_I+5,dustfluxtosed_idx_t=LAST_I+6,
     &   pocsedloss_idx_t=LAST_I+7,otherremin_idx_t=LAST_I+8,caco3sedloss_idx_t=LAST_I+9,
     &   sio2sedloss_idx_t=LAST_I+10 

      ! Array for storing the Netcdf variable IDs of the diagnostics:
      ! The IDs of the 2d vars are first, the those of the 3d.
      integer hisT_bec2_diag(nr_bec2_diag), avgT_bec2_diag(nr_bec2_diag), slavgT_bec2_diag(nr_bec2_diag),
     &        rstT_bec2_diag(nr_bec2_diag)

      ! Arrays storing information (name, unit, fill value) about each diagnostic variable:
      character*72  vname_bec2_diag_2d(4,nr_bec2_diag_2d)
      character*72  vname_bec2_diag_3d(4,nr_bec2_diag_3d)

      common /bec2_diag2/ hisT_bec2_diag, avgT_bec2_diag, slavgT_bec2_diag, rstT_bec2_diag,
     &   vname_bec2_diag_2d, vname_bec2_diag_3d

# ifdef BEC2_DIAG_USER
#  ifdef AVERAGES
      real, pointer, dimension(:,:,:,:) :: bec2_diag_3d_avg
      real, pointer, dimension(:,:,:) ::  bec2_diag_2d_avg
#   ifdef SLICE_AVG
      real, pointer, dimension(:,:,:) ::   bec2_diag_3d_slavg
      real, pointer, dimension(:,:,:) ::   bec2_diag_2d_slavg
#   endif
#  endif /* AVERAGES */
# else /* BEC2_DIAG_USER */
#  ifdef AVERAGES
      real bec2_diag_3d_avg(GLOBAL_2D_ARRAY,N,nr_bec2_diag_3d)
      real bec2_diag_2d_avg(GLOBAL_2D_ARRAY,nr_bec2_diag_2d)
#   ifdef SLICE_AVG
      real bec2_diag_3d_slavg(GLOBAL_2D_ARRAY,nr_bec2_diag_3d)
      real bec2_diag_2d_slavg(GLOBAL_2D_ARRAY,nr_bec2_diag_2d)
#   endif
#  endif /* AVERAGES */
# endif /* BEC2_DIAG_USER */
# ifdef AVERAGES
      common /bec2_diag3/ bec2_diag_3d_avg, bec2_diag_2d_avg
#  ifdef SLICE_AVG
     &    , bec2_diag_3d_slavg, bec2_diag_2d_slavg
#  endif
# endif /* AVERAGES */
!#else
!mm does not compile:
!      real PH_HIST(GLOBAL_2D_ARRAY)
!      common /ph_hist_com/ PH_HIST
#endif /* BEC2_DIAG */

!     IFRAC  sea ice fraction (non-dimensional)
!     PRESS  sea level atmospheric pressure (Pascals)
      real ifrac(GLOBAL_2D_ARRAY),
     &   press(GLOBAL_2D_ARRAY)
      common /fic_ap/ ifrac,press

      logical landmask(GLOBAL_2D_ARRAY)
      common /calcation/landmask

      logical lsource_sink,lflux_gas_o2, lflux_gas_co2
#if defined EXPLICIT_MICROBES
     &  ,lflux_gas_n2o
     &  ,lflux_gas_n2
# endif
     &  ,liron_flux,ldust_flux
#ifdef RIVER_LOAD_N
     &  ,lriver_load_n
#endif
#ifdef RIVER_LOAD_P
     &  ,lriver_load_p
#endif
#ifdef RIVER_LOAD_ALK_DIC_SI
     &  ,lriver_load_alk,lriver_load_dic,lriver_load_si
#endif
      common /ecoflag/lsource_sink,lflux_gas_o2,lflux_gas_co2,
     &   liron_flux,ldust_flux
#ifdef RIVER_LOAD_N
     &  ,lriver_load_n
#endif
#ifdef RIVER_LOAD_P
     &  ,lriver_load_p
#endif
#ifdef RIVER_LOAD_ALK_DIC_SI
     &  , lriver_load_alk,lriver_load_dic,lriver_load_si
#endif

!
! Relative tracer indices for prognostic variables:
!
      integer po4_ind_t, no3_ind_t, sio3_ind_t, nh4_ind_t, fe_ind_t, dic_ind_t, alk_ind_t,
     &        o2_ind_t, doc_ind_t, don_ind_t, dofe_ind_t, dop_ind_t, dopr_ind_t, donr_ind_t,
     &        zooc_ind_t, spchl_ind_t, spc_ind_t, spfe_ind_t, spcaco3_ind_t, diatchl_ind_t,
     &        diatc_ind_t, diatfe_ind_t, diatsi_ind_t, diazchl_ind_t, diazc_ind_t, diazfe_ind_t
      parameter( po4_ind_t=1, no3_ind_t=2, sio3_ind_t=3, nh4_ind_t=4, fe_ind_t=5,
     &    o2_ind_t=6, dic_ind_t=7, alk_ind_t=8, doc_ind_t=9, don_ind_t=10, dofe_ind_t=11,
     &    dop_ind_t=12, dopr_ind_t=13, donr_ind_t=14, zooc_ind_t=15, spc_ind_t=16,
     &    spchl_ind_t=17, spfe_ind_t=18, spcaco3_ind_t=19, diatc_ind_t=20, diatchl_ind_t=21,
     &    diatfe_ind_t=22, diatsi_ind_t=23, diazc_ind_t=24, diazchl_ind_t=25, diazfe_ind_t=26
# undef LAST_I
# define LAST_I diazfe_ind_t
     &)
#ifdef EXPLICIT_MICROBES
      integer, parameter ::
     &     no2_ind_t=LAST_I+1, n2_ind_t=LAST_I+2, n2o_ind_t=LAST_I+3,
     &     aoa_ind_t=LAST_I+4, nob_ind_t=LAST_I+5, aox_ind_t=LAST_I+6,
     &     aer_ind_t=LAST_I+7, nar_ind_t=LAST_I+8, nai_ind_t=LAST_I+9, 
     &     nir_ind_t=LAST_I+10, nio_ind_t=LAST_I+11, nos_ind_t=LAST_I+12,
     &     nao_ind_t=LAST_I+13, docr_ind_t=LAST_I+14
# ifdef HETERO_GRAZING
     &     , szooc_ind_t=LAST_I+15
#   undef LAST_I
#   define LAST_I szooc_ind_t
#  else
#   undef LAST_I
#   define LAST_I docr_ind_t
#  endif
# endif

!
! Parameters related to sinking particles:
!

      real 
     &   POC_diss,       ! diss. length (m), modified by TEMP
     &   POC_mass,       ! molecular weight of POC
     &   P_CaCO3_diss,   ! diss. length (m)
     &   P_CaCO3_gamma,  ! prod frac -> hard subclass
     &   P_CaCO3_mass,   ! molecular weight of CaCO
     &   P_CaCO3_rho,    ! QA mass ratio for CaCO3
     &   P_SiO2_diss,    ! diss. length (m), modified by TEMP
     &   P_SiO2_gamma,   ! prod frac -> hard subclass
     &   P_SiO2_mass,    ! molecular weight of SiO2
     &   P_SiO2_rho,     ! QA mass ratio for SiO2
     &   dust_diss,      ! diss. length (m)
     &   dust_gamma,     ! prod frac -> hard subclass
     &   dust_mass,      ! base units are already grams
     &   dust_rho,       ! QA mass ratio for dust
     &   P_iron_gamma,    ! prod frac -> hard subclass
     &   POC_gamma       ! prod frac -> hard subclass


      common /sinking_particles1/ POC_diss,POC_mass,P_CaCO3_diss,
     &   P_CaCO3_mass,P_CaCO3_rho,P_SiO2_diss,P_SiO2_mass,P_SiO2_rho,
     &   dust_diss,dust_mass,dust_rho

      ! The gamma parameters are set init_particulate_terms and so they
      ! need to be in a common block:
      common /sinking_particles1/ POC_gamma, P_CaCO3_gamma, P_SiO2_gamma,
     &   dust_gamma, P_iron_gamma
!
! Arrays related to sinking particles:
!
!  *_hflux_in: incoming flux of hard subclass (base units/m^2/sec)
!  *_hflux_out: outgoing flux of hard subclass (base units/m^2/sec)
!  *_sflux_in: incoming flux of soft subclass (base units/m^2/sec)
!  *_sflux_out: outgoing flux of soft subclass (base units/m^2/sec)
!  *_sed_loss: loss to sediments (base units/m^2/sec)
!  *_remin: remineralization term (base units/m^3/sec)

      real, dimension(GLOBAL_2D_ARRAY) ::
     &   P_CaCO3_sflux_out, P_CaCO3_hflux_out,
     &   P_SiO2_sflux_out, P_SiO2_hflux_out,
     &   dust_sflux_out, dust_hflux_out,
     &   P_iron_sflux_out, P_iron_hflux_out,
     &   POC_sflux_out, POC_hflux_out, 
     &   P_CaCO3_sflux_in, P_CaCO3_hflux_in,
     &   P_SiO2_sflux_in, P_SiO2_hflux_in, 
     &   dust_sflux_in, dust_hflux_in,
     &   P_iron_sflux_in, P_iron_hflux_in,
     &   POC_sflux_in, POC_hflux_in,
     &   P_CaCO3_sed_loss, P_SiO2_sed_loss, 
     &   P_iron_sed_loss,POC_sed_loss,
     &   dust_sed_loss,
     &   DOP_remin, DOPr_remin

      real, dimension(GLOBAL_2D_ARRAY) ::
     &   POC_remin, P_iron_remin, P_SiO2_remin, P_CaCO3_remin

      common /sinking_particles2/
     &   P_CaCO3_sflux_out, P_CaCO3_hflux_out,
     &   P_SiO2_sflux_out, P_SiO2_hflux_out,
     &   dust_sflux_out, dust_hflux_out,
     &   P_iron_sflux_out, P_iron_hflux_out,
     &   POC_sflux_out, POC_hflux_out,
     &   P_CaCO3_sflux_in, P_CaCO3_hflux_in,
     &   P_SiO2_sflux_in, P_SiO2_hflux_in, 
     &   dust_sflux_in, dust_hflux_in,
     &   P_iron_sflux_in, P_iron_hflux_in,
     &   POC_sflux_in, POC_hflux_in,
     &   P_CaCO3_sed_loss, P_SiO2_sed_loss, 
     &   P_iron_sed_loss,POC_sed_loss,
     &   dust_sed_loss,
     &   DOP_remin, DOPr_remin,
     &   POC_remin, P_iron_remin, P_SiO2_remin, P_CaCO3_remin

!
! Arrays related to carbon chemistry: these are in bec2_diag_2d or
! bec2_diag_3d if BEC2_DIAG is defined
!
#ifndef BEC2_DIAG
      real, dimension(GLOBAL_2D_ARRAY) ::
     &   ph_hist, pCO2sw, PARinc
      real, dimension(GLOBAL_2D_ARRAY,N) ::
     &   PAR
      common /c_chem/ ph_hist, pCO2sw, PARinc, PAR
# ifndef PCO2AIR_FORCING
!     otherwise defined in bgc_forces.h
      real pco2air
      common /c_chem/pco2air
# endif

      real, dimension(GLOBAL_2D_ARRAY) ::
     &   ph_avg, pCO2_avg, pCO2air_avg, PARinc_avg
      real, dimension(GLOBAL_2D_ARRAY,N) ::
     &   PAR_avg
      common /time_avg1/ PAR_avg, PARinc_avg, 
     &        pco2_avg, pCO2air_avg, pH_avg
# ifdef SLICE_AVG
      real PAR_slavg(GLOBAL_2D_ARRAY)
      real PARinc_slavg(GLOBAL_2D_ARRAY)
      real pco2_slavg(GLOBAL_2D_ARRAY)
      real pCO2air_slavg(GLOBAL_2D_ARRAY)
      real pH_slavg(GLOBAL_2D_ARRAY)
      common /time_slavg1/ PAR_slavg, PARinc_slavg, 
     &        pco2_slavg, pCO2air_slavg, pH_slavg
# endif /* SLICE_AVG */
#endif /* !BEC2_DIAG */
