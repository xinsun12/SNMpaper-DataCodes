! Parameters related to BEC model
      real c1, c0, c2,c10,c1000,p5,spd,dps,t0_kelvin,yps,mpercm
       parameter (
     & c1=1., 
     & c0=0.0,
     & c2=2., 
     & c10=10.,
     & c1000=1000.,
     & p5=0.5,
     & spd = 86400.0,  
     & dps = c1 / spd,           ! number of days per second
     & yps = c1 / (365.0*spd),   ! number of years in a second
     & mpercm = .01,             ! meters per cm
     & t0_kelvin= 273.16)

! Parameters related to autotrophs: how many, how they are ordered
       integer, parameter :: autotroph_cnt=3
       integer, parameter ::
     &   sp_ind   = 1,  ! small phytoplankton
     &   diat_ind = 2,  ! diatoms
     &   diaz_ind = 3   ! diazotrophs

!
! The following arrays contain one parameter for all of the 3 or 4 autotrophs, in the
! following order:
!  1 --> small phytoplankton
!  2 --> diatoms
!  3 --> diazotrophs
!
       character*24 sname(autotroph_cnt)     ! short name of each autotroph
       character*80 lname(autotroph_cnt)     ! long name of each autotroph
       integer
     &   Chl_ind(autotroph_cnt),             ! tracer indices for Chl
     &   C_ind(autotroph_cnt),               ! tracer indices for C
     &   Fe_ind(autotroph_cnt),              ! tracer indices for Fe
     &   Si_ind(autotroph_cnt),              ! tracer indices for Si
     &   CaCO3_ind(autotroph_cnt)            ! tracer indices for Si, CaCO3 content
       real
     &   kFe(autotroph_cnt),                 ! nutrient uptake half-sat constant (mmol/m3)
     &   kPO4(autotroph_cnt),                ! nutrient uptake half-sat constant (mmol/m3)
     &   kDOP(autotroph_cnt),                ! nutrient uptake half-sat constant (mmol/m3)
     &   kNO3(autotroph_cnt),                ! nutrient uptake half-sat constant (mmol/m3)
     &   kNO2(autotroph_cnt),                ! nutrient uptake half-sat constant (mmol/m3)
     &   kNH4(autotroph_cnt),                ! nutrient uptake half-sat constant (mmol/m3)
     &   kSiO3(autotroph_cnt),               ! nutrient uptake half-sat constant (mmol/m3)
     &   Qp(autotroph_cnt),                  ! P/C ratio
     &   gQfe_0(autotroph_cnt),              ! Fe/C ratio
     &   gQfe_min(autotroph_cnt),            ! initial and minimum fe/C ratios
     &   alphaPI(autotroph_cnt),             ! init slope of P_I curve (GD98) (mmol C m^2/(mg Chl W sec))
     &   PCref(autotroph_cnt),               ! max C-spec. grth rate at tref (1/sec)
     &   thetaN_max(autotroph_cnt),          ! max thetaN (Chl/N) (mg Chl/mmol N)
     &   loss_thres(autotroph_cnt),          ! conc. where losses go to zero
     &   loss_thres2(autotroph_cnt),         ! conc. where losses go to zero
     &   temp_thres(autotroph_cnt),          ! Temp. where concentration threshold and photosynth. rate drops
     &   mort(autotroph_cnt),                ! linear mortality rates (1/sec), (1/sec/((mmol C/m3))
     &   mort2(autotroph_cnt),               ! quadratic mortality rates (1/sec), (1/sec/((mmol C/m3))
     &   agg_rate_max(autotroph_cnt),        ! max agg. rate (1/d)
     &   agg_rate_min(autotroph_cnt),        ! min agg. rate (1/d)
     &   z_umax_0(autotroph_cnt),            ! max zoo growth rate at tref (1/sec)
     &   z_grz(autotroph_cnt),               ! grazing coef. (mmol C/m^3)
     &   graze_zoo(autotroph_cnt),           ! routing of grazed term, remainder goes to dic
     &   graze_poc(autotroph_cnt),           ! routing of grazed term, to POC
     &   graze_doc(autotroph_cnt),           ! routing of grazed term, to DOC 
     &   loss_poc(autotroph_cnt),            ! routing of loss term
     &   f_zoo_detr(autotroph_cnt)           ! fraction of zoo losses to detrital
       integer grazee_ind(autotroph_cnt)     ! which grazee category does autotroph belong to
       logical Nfixer(autotroph_cnt)         ! flag set to true for autotrophs that fix N2
       logical imp_calcifier(autotroph_cnt)  ! flag set to true if autotroph implicitly handles calcification
       logical exp_calcifier(autotroph_cnt)  ! flag set to true if autotroph explicitly handles calcification
       
       common /ecosys_bec1/ Chl_ind, C_ind, Fe_ind, Si_ind, CaCO3_ind, grazee_ind
     &        , Nfixer, imp_calcifier, exp_calcifier, sname, lname
       common /ecosys_bec_reals/ kFe, kPO4, kDOP, kNO3, kNO2, kNH4, kSiO3,
     &        Qp, gQfe_0, gQfe_min, alphaPI, PCref, thetaN_max, loss_thres, loss_thres2,
     &        temp_thres, mort, mort2, agg_rate_max, agg_rate_min, z_umax_0, z_grz,
     &        graze_zoo, graze_poc, graze_doc, loss_poc, f_zoo_detr


# ifdef EXPLICIT_MICROBES
! Parameters related to chemoautotrophs: how many, how they are ordered
       integer, parameter :: chemo_cnt=3
       integer, parameter ::
     &   aoa_ind = 1,  ! ammonia oxidizing archaea
     &   nob_ind = 2,  ! nitrite oxidizing bacteria
     &   aox_ind = 3   ! anammox bacteria

!
! The following arrays contain one parameter for all of the 3 chemoautotrophs, in the
! following order:
!  1 --> ammonia oxidizing archaea 
!  2 --> nitrite oxidizing bacteria
!  3 --> anammox bacteria
!
       character*24 chemo_sname(chemo_cnt)     ! short name of each chemoautotroph
       character*80 chemo_lname(chemo_cnt)     ! long name of each chemoautotroph
       integer
     &   chemo_C_ind(chemo_cnt)                ! amount of C in each chemoautotroph species
       real
     &   chemo_bmin(chemo_cnt),                ! minimum biomass (mmol/m3) 
     &   chemo_kzoo(chemo_cnt),                ! grazing half-saturation coefficient (mmol/m3) 
     &   chemo_CN(chemo_cnt),                  ! C:N ratio of biomass 
     &   chemo_CP(chemo_cnt),                  ! C:P ratio of biomass 
     &   chemo_CFe(chemo_cnt),                 ! C:Fe ratio of biomass 
     &   chemo_m_l(chemo_cnt),                 ! Linear mortality (1/s) 
     &   chemo_m_q(chemo_cnt),                 ! Quadratic mortality (m3/mmol s) 
     &   chemo_mortdoc(chemo_cnt),             ! Fraction of mortality to DOC pool (%) 
     &   chemo_mortpoc(chemo_cnt),             ! Fraction of mortality to POC pool (%)
     &   chemo_pcoef(chemo_cnt),               ! Diffusive uptake rate of O2 (m3/mmol C/s) 
     &   chemo_Vmax_oxy(chemo_cnt),            ! Max specific resource uptake (mol DIN/mol B s) 
     &   chemo_Vmax_red(chemo_cnt),            ! Max specific resource uptake (mol DIN/mol B s) 
     &   chemo_K_oxy(chemo_cnt),               ! Oxidant half-saturation constant (mmol/m3) 
     &   chemo_K_red(chemo_cnt),               ! Reductant half-saturation constant (mmol/m3)
     &   chemo_y_oxy(chemo_cnt),               ! Oxidant biomass yield (mol DIN/mol B) 
     &   chemo_y_red(chemo_cnt),               ! Reductant biomass yield (mol DIN/mol B)
     &   chemo_y_dic(chemo_cnt),               ! DIC biomass yield (mol DIC/mol B)
     &   chemo_y_nh4(chemo_cnt),               ! Biomass yield via NH4 (mol DIN/mol B)
     &   chemo_y_po4(chemo_cnt),               ! Biomass yield via PO4 (mol DIP/mol B)
     &   chemo_e_no2(chemo_cnt),               ! Excretion of NO2 due to growth (mol N/mol B)
     &   chemo_e_no3(chemo_cnt),               ! Excretion of NO3 due to growth (mol N/mol B)
     &   chemo_e_n2(chemo_cnt)                 ! Excretion of N2 due to growht (mol N2/mol B)
       logical chemo_diffusive(chemo_cnt)      ! Logical for diffusive uptake (false = Michaelis) 

       common /chemos/ chemo_sname, chemo_lname, chemo_C_ind, chemo_diffusive 
       common /chemos_reals/ chemo_bmin, chemo_kzoo, chemo_CN, chemo_CP,
     &        chemo_CFe, chemo_m_l, chemo_m_q, chemo_mortdoc, chemo_mortpoc, chemo_pcoef, 
     &        chemo_Vmax_oxy, chemo_Vmax_red, chemo_K_oxy, chemo_K_red, chemo_y_oxy, chemo_y_red, chemo_y_dic,
     &        chemo_y_nh4, chemo_y_po4, chemo_e_no2, chemo_e_no3, chemo_e_n2 


! Parameters related to heterotrophs: how many, how they are ordered
       integer, parameter :: hetero_cnt=7
       integer, parameter ::
     &   aer_ind = 1,  ! obligate aerobic type 
     &   nar_ind = 2,  ! NO3->NO2 type 
     &   nai_ind = 3,  ! NO3->N2O type 
     &   nao_ind = 4,  ! NO3->N2 type 
     &   nir_ind = 5,  ! NO2->N2O type 
     &   nio_ind = 6,  ! NO2->N2 type 
     &   nos_ind = 7   ! N2O->N2 type 

!
! The following arrays contain one parameter for all of the 7 heterotrophs, in the
! following order:
!  1 --> AER, obligate aerobic type 
!  2 --> NAR, NO3->NO2 type 
!  3 --> NAI, NO3->N2O type 
!  4 --> NAO, NO3->N2 type 
!  5 --> NIR, NO2->N2O type 
!  6 --> NIO, NO2->N2 type 
!  7 --> NOS, N2O->N2 type 
!
       character*24 hetero_sname(hetero_cnt)     ! short name of each heterotroph
       character*80 hetero_lname(hetero_cnt)     ! long name of each heterotroph
       integer
     &   hetero_C_ind(hetero_cnt)                ! amount of C in each heterotrophic bacteria
       real
     &   hetero_bmin(hetero_cnt),                ! minimum biomass (mmol/m3) 
     &   hetero_kszoo(hetero_cnt),               ! grazing half-saturation coefficient (mmol/m3) 
     &   hetero_CN(hetero_cnt),                  ! C:N ratio of biomass 
     &   hetero_CP(hetero_cnt),                  ! C:P ratio of biomass 
     &   hetero_CFe(hetero_cnt),                 ! C:Fe ratio of biomass 
     &   hetero_m_l(hetero_cnt),                 ! Linear mortality (1/s) 
     &   hetero_m_q(hetero_cnt),                 ! Quadratic mortality (m3/mmol s) 
     &   hetero_mortdoc(hetero_cnt),             ! Fraction of mortality to DOC pool (%) 
     &   hetero_mortpoc(hetero_cnt),             ! Fraction of mortality to POC pool (%)
     &   hetero_K_doc(hetero_cnt),               ! DOC half-saturation constant (mmol/m3)
     &   hetero_K_docr(hetero_cnt),              ! DOCr half-saturation constant (mmol/m3)
     &   hetero_pcoef(hetero_cnt),               ! Diffusive uptake rate of O2 (m3/mmol C/s) (aerobic metabolims) 
     &   hetero_Vmax_oxy_aer(hetero_cnt),        ! Max specific resource uptake (mol oxy/mol B s) (aerobic metabolims) 
     &   hetero_Vmax_red_aer(hetero_cnt),        ! Max specific resource uptake (mol DOC/mol B s) (aerobic metabolims) 
     &   hetero_K_oxy_aer(hetero_cnt),           ! Oxidant half-saturation constant (mmol/m3) (aerobic metabolims) 
     &   hetero_y_oxy_aer(hetero_cnt),           ! Oxidant biomass yield (mol DIN/mol B) (aerobic metabolism)
     &   hetero_y_red_aer(hetero_cnt),           ! Reducant biomass yield (mol DIN/mol B) (aerobic metabolism)
     &   hetero_e_dic_aer(hetero_cnt),           ! Excretion of DIC due to growth (mol DIC/mol B) (aerobic metabolism)
     &   hetero_e_nh4_aer(hetero_cnt),           ! Excretion of NH4 due to growth (mol N/mol B) (aerobic metabolism)
     &   hetero_e_po4_aer(hetero_cnt),           ! Excretion of PO4 due to growth (mol P/mol B) (aerobic metabolism)
     &   hetero_pana(hetero_cnt),                ! Diffusive uptake rate of DIN (m3/mmol C/s) (anaerobic metabolism)
     &   hetero_Vmax_oxy_ana(hetero_cnt),        ! Max specific resource uptake (mol oxy/mol B s) (anaerobic metabolims)
     &   hetero_Vmax_red_ana(hetero_cnt),        ! Max specific resource uptake (mol DOC/mol B s) (anaerobic metabolims)
     &   hetero_K_oxy_ana(hetero_cnt),           ! Oxidant half-saturation constant (mmol/m3) (anaerobic metabolims) 
     &   hetero_y_oxy_ana(hetero_cnt),           ! Oxidant biomass yield (mol oxy/mol B) (anaerobic metabolism)
     &   hetero_y_red_ana(hetero_cnt),           ! Reducant biomass yield (mol DOC/mol B) (anaerobic metabolism)
     &   hetero_e_dic_ana(hetero_cnt),           ! Excretion of DIC (mol DIC/mol B) (anaerobic metabolism)
     &   hetero_e_nh4_ana(hetero_cnt),           ! Excretion of NH4 (mol N/mol B) (anaerobic metabolism)
     &   hetero_e_po4_ana(hetero_cnt),           ! Excretion of PO4 (mol P/mol B) (anaerobic metabolism)
     &   hetero_e_no2_ana(hetero_cnt),           ! Excretion of NO2 (mol N/mol B) (anaerobic metabolism)
     &   hetero_e_n2o_ana(hetero_cnt),           ! Excretion of N2O (mol N2/mol B) (anaerobic metabolism)
     &   hetero_e_n2_ana(hetero_cnt)             ! Excretion of N2 (mol N2/mol B) (anaerobic metabolism)
       logical hetero_diffusive_aer(hetero_cnt)  ! Logical for diffusive uptake (false = Michaelis) (aerobic metabolism)
       logical hetero_diffusive_ana(hetero_cnt)  ! Logical for diffusive uptake (false = Michaelis) (anaerobic metabolism)

       common /heteros/ hetero_sname, hetero_lname, hetero_C_ind, hetero_diffusive_aer, hetero_diffusive_ana
       common /heteros_reals/ hetero_bmin, hetero_kszoo, hetero_CN, hetero_CP,
     &        hetero_CFe, hetero_m_l, hetero_m_q, hetero_mortdoc, hetero_mortpoc, hetero_K_doc, hetero_K_docr, 
     &        hetero_pcoef, hetero_Vmax_oxy_aer, hetero_Vmax_red_aer, hetero_K_oxy_aer, 
     &        hetero_y_oxy_aer, hetero_y_red_aer, hetero_e_dic_aer, hetero_e_nh4_aer, hetero_e_po4_aer,
     &        hetero_pana, hetero_Vmax_oxy_ana, hetero_Vmax_red_ana, hetero_K_oxy_ana, 
     &        hetero_y_oxy_ana, hetero_y_red_ana, hetero_e_dic_ana, hetero_e_nh4_ana, hetero_e_po4_ana,
     &        hetero_e_no2_ana, hetero_e_n2o_ana, hetero_e_n2_ana

# endif


!-----------------------------------------------------------------------------
!   Redfield Ratios, dissolved & particulate
!-----------------------------------------------------------------------------

       real parm_Red_D_C_P, parm_Red_D_N_P, parm_Red_D_O2_P, parm_Remin_D_O2_P,
     &   parm_Red_P_C_P, parm_Red_D_C_N, parm_Red_P_C_N, parm_Red_D_C_O2,
     &   parm_Remin_D_C_O2, parm_Red_P_C_O2, parm_Red_Fe_C, parm_Red_D_C_O2_diaz
# ifdef EXPLICIT_MICROBES
     &   ,parm_Red_D_C_O2_NO2V
     &   ,parm_Remin_M_O2_P
# endif
       parameter(
     &   parm_Red_D_C_P  = 117.0,                              ! carbon:phosphorus
     &   parm_Red_D_N_P  =  16.0,                              ! nitrogen:phosphorus
     &   parm_Red_D_O2_P = 170.0,                              ! oxygen:phosphorus
     &   parm_Remin_D_O2_P = 138.0,                            ! oxygen:phosphorus
     &   parm_Red_P_C_P  = parm_Red_D_C_P,                     ! carbon:phosphorus
     &   parm_Red_D_C_N  = parm_Red_D_C_P/parm_Red_D_N_P,      ! carbon:nitrogen
     &   parm_Red_P_C_N  = parm_Red_D_C_N,                     ! carbon:nitrogen
     &   parm_Red_D_C_O2 = parm_Red_D_C_P/parm_Red_D_O2_P,     ! carbon:oxygen for HNO3 uptake (assuming OM is C117H297O85N16P)
     &   parm_Remin_D_C_O2 = parm_Red_D_C_P/parm_Remin_D_O2_P, ! carbon:oxygen for NH3 uptake (assuming OM is C117H297O85N16P)
     &   parm_Red_P_C_O2 = parm_Red_D_C_O2,                    ! carbon:oxygen
     &   parm_Red_Fe_C   = 3.0e-6,                             ! iron:carbon
     &   parm_Red_D_C_O2_diaz = parm_Red_D_C_P/150.0           ! carbon:oxygen for diazotrophs
# ifdef EXPLICIT_MICROBES
     &   ,parm_Red_D_C_O2_NO2V = parm_Red_D_C_P/162.0          ! carbon:oxygen for HNO2 uptake (assuming OM is C117H297O85N16P)
     &   ,parm_Remin_M_O2_P = 55/56.25                         ! carbon:oxygen for instant remin of microbial biomass
# endif 
     & )

!----------------------------------------------------------------------------
!   ecosystem parameters accessible via namelist input
!----------------------------------------------------------------------------

       real
     &   parm_Fe_bioavail,        ! fraction of Fe flux that is bioavailable
     &   parm_o2_min,             ! min O2 needed for prod & consump. (nmol/cm^3)
     &   parm_o2_min_delta,       ! width of min O2 range (nmol/cm^3)
     &   parm_lowo2_remin_factor, ! remineralization slowdown factor at low o2
     &   parm_kappa_nitrif,       ! nitrification inverse time constant (1/sec)
# ifdef TDEP_REMIN
     &   parm_ktfunc_soft,        ! parameter for the temperature dependance of remin on temp (Laufkoeuter 2017)
# endif
# ifdef EXPLICIT_MICROBES
     &   parm_n2o_ji_a,        ! n2o yield constant (Ji et al.  2015)
     &   parm_n2o_ji_b,        ! n2o yield constant (Ji et al.  2015)
#  ifdef HETERO_GRAZING
     &   parm_szoo_mumax,     ! maximum growth rate of small zooplankton
     &   parm_szoo_lmort,     ! linear mortality rate for small zooplankton
     &   parm_szoo_qmort,     ! quadratic mortality rate for small zooplankton
     &   parm_szoo_labil,     ! fraction of small zooplankton loss routed to DIC
     &   parm_szoo_fdetr,     ! fraction of small zooplankton loss routed to POC
     &   parm_szoo_losst,     ! concentration of small zooplankton beneath which losses don't occur
     &   parm_szoo_bmin,      ! minimum C biomass beneath which losses do not occur (mmol C / m3)
#  endif 
# endif
     &   parm_nitrif_par_lim,    ! PAR limit for nitrif. (W/m^2)
     &   parm_z_mort_0,          ! zoo linear mort rate (1/sec)
     &   parm_z_mort2_0,         ! zoo quad mort rate (1/sec/((mmol C/m3))
     &   parm_labile_ratio,      ! fraction of loss to DOC that routed directly to DIC (non-dimensional)
     &   parm_POMbury,           ! scale factor for burial of POC, PON, and POP
     &   parm_BSIbury,           ! scale factor burial of bSi
     &   parm_Fe_scavenge_rate0, ! base scavenging rate
     &   parm_f_prod_sp_CaCO3,   ! fraction of sp prod. as CaCO3 prod.
     &   parm_POC_diss,          ! base POC diss len scale
     &   parm_SiO2_diss,         ! base SiO2 diss len scale
     &   parm_CaCO3_diss         ! base CaCO3 diss len scale

       real 
     &   parm_scalelen_z(4),     ! depths of prescribed scalelen values
     &   parm_scalelen_vals(4)   ! prescribed scalelen values

       common /ecosys_bec2/ parm_Fe_bioavail, parm_o2_min, parm_o2_min_delta, parm_lowo2_remin_factor, parm_kappa_nitrif,
     &   parm_nitrif_par_lim, parm_z_mort_0, parm_z_mort2_0, parm_labile_ratio, parm_POMbury,
     &   parm_BSIbury, parm_Fe_scavenge_rate0, parm_f_prod_sp_CaCO3, parm_POC_diss,
     &   parm_SiO2_diss, parm_CaCO3_diss,
     &   parm_scalelen_z, parm_scalelen_vals
# ifdef TDEP_REMIN
     &   , parm_ktfunc_soft
# endif
# ifdef EXPLICIT_MICROBES
     &   , parm_n2o_ji_a, parm_n2o_ji_b
#  ifdef HETERO_GRAZING
     &   , parm_szoo_mumax, parm_szoo_lmort, parm_szoo_qmort, parm_szoo_labil
     &   , parm_szoo_fdetr, parm_szoo_losst, parm_szoo_bmin
#  endif
# endif

!---------------------------------------------------------------------
!     Misc. Rate constants
!---------------------------------------------------------------------
!
! DL: dust_fescav_scale changed from 1e9 to 1e10 since dust fluxes in ROMS
! are in kg dust/(m^2 s) = 0.1 g dust/(cm^2 s)
!---------------------------------------------------------------------

       real fe_scavenge_thres1, dust_fescav_scale, fe_max_scale2
       parameter(
     &   fe_scavenge_thres1 = 0.8e-3,   ! upper thres. for Fe scavenging (mmol/m^3)
     &   dust_fescav_scale  = 1.0e10,   ! dust scavenging scale factor (was 1e9 in CESM)
     &   fe_max_scale2      = 1200.0    ! unitless scaling coeff.
     & )

!---------------------------------------------------------------------
!     Compute iron remineralization and flux out. In CESM units
!     dust remin gDust = 0.035 gFe      mol Fe     1e9 nmolFe
!                        --------- *  ---------- * ----------
!                         gDust       55.847 gFe     molFe
!
!     dust_to_Fe          conversion - dust to iron (CESM: nmol Fe/g Dust) 
!---------------------------------------------------------------------
!
! DL: in ROMS we have to convert kg dust -> mmol Fe, so the above calculation
! becomes:
!
!                    0.035 kg Fe         mol Fe         1e3 mmolFe              mmol Fe
! dust remin gDust = ---------    *  ---------------- * ----------  =  626.712  -------
!                     kg dust        55.847e-3 kg Fe      molFe                 kg dust

       real dust_to_Fe
       parameter(dust_to_Fe=0.035/55.847*1.0e6)  ! mmol Fe/kg dust

!----------------------------------------------------------------------------
!     Partitioning of phytoplankton growth, grazing and losses
!
!     All f_* variables are fractions and are non-dimensional
!----------------------------------------------------------------------------

       real caco3_poc_min, spc_poc_fac, f_graze_sp_poc_lim,
     &   f_photosp_CaCO3, f_graze_CaCO3_remin, f_graze_si_remin
       parameter(
     &   caco3_poc_min    = 0.4,  ! minimum proportionality between 
     &                            !   QCaCO3 and grazing losses to POC 
     &                            !   (mmol C/mmol CaCO3)
     &   spc_poc_fac      = 0.14, ! small phyto grazing factor (1/mmolC)
     &   f_graze_sp_poc_lim = 0.36, 
     &   f_photosp_CaCO3  = 0.4,  ! proportionality between small phyto 
     &                            ! production and CaCO3 production
     &   f_graze_CaCO3_remin = 0.33, ! fraction of spCaCO3 grazing 
     &                               !          which is remin
     &   f_graze_si_remin    = 0.35  ! fraction of diatom Si grazing 
     &                               !          which is remin
     & )

!----------------------------------------------------------------------------
!     fixed ratios
!----------------------------------------------------------------------------

       real r_Nfix_photo
       parameter(r_Nfix_photo=1.25)         ! N fix relative to C fix (non-dim)

!-----------------------------------------------------------------------
!     SET FIXED RATIOS for N/C, P/C, SiO3/C, Fe/C
!     assumes C/N/P of 117/16/1 based on Anderson and Sarmiento, 1994
!     for diazotrophs a N/P of 45 is assumed based on Letelier & Karl, 1998
!-----------------------------------------------------------------------

       real Q, Qp_zoo_pom, Qfe_zoo, gQsi_0, gQsi_max, gQsi_min, QCaCO3_max,
     &   denitrif_C_N, denitrif_NO3_C, denitrif_NO2_C, denitrif_N2O_C
       parameter(
     &   Q             = 0.137,   !N/C ratio (mmol/mmol) of phyto & zoo
     &   Qp_zoo_pom    = 0.00855, !P/C ratio (mmol/mmol) zoo & pom
     &   Qfe_zoo       = 3.0e-6,  !zooplankton fe/C ratio
     &   gQsi_0        = 0.137,   !initial Si/C ratio
     &   gQsi_max      = 0.8,     !max Si/C ratio
     &   gQsi_min      = 0.0429,  !min Si/C ratio
     &   QCaCO3_max    = 0.4,     !max QCaCO3
     &   ! carbon:nitrogen ratio for denitrification
     &   denitrif_C_N  = parm_Red_D_C_P/136.0,
     &   denitrif_NO3_C  = 472.0 / 2.0 / 106.0, ! need to comment on that and check 
     &   denitrif_NO2_C  = 472.0 / 2.0 / 106.0,
     &   denitrif_N2O_C  = 472.0 / 2.0 / 106.0
     & )

!----------------------------------------------------------------------------
!     loss term threshold parameters, chl:c ratios
!----------------------------------------------------------------------------

       real thres_z1, thres_z2, loss_thres_zoo, CaCO3_temp_thres1,
     &   CaCO3_temp_thres2, CaCO3_sp_thres
       parameter(
     &   thres_z1          = 100.0,    ! threshold = C_loss_thres for z shallower than this (m)
     &   thres_z2          = 150.0,    ! threshold = 0 for z deeper than this (m)
     &   loss_thres_zoo    = 0.06,     ! zoo conc. where losses go to zero
     &   CaCO3_temp_thres1 = 6.0,      ! upper temp threshold for CaCO3 prod
     &   CaCO3_temp_thres2 = -2.0,     ! lower temp threshold
     &   CaCO3_sp_thres    = 2.5       ! bloom condition thres (mmolC/m3)
     & )

!---------------------------------------------------------------------
!     fraction of incoming shortwave assumed to be PAR
!---------------------------------------------------------------------

       real f_qsw_par
       parameter(f_qsw_par = 0.45)   ! PAR fraction

!---------------------------------------------------------------------
!     Temperature parameters
!---------------------------------------------------------------------

       real Tref, Q_10
       parameter(
     &   Tref = 30.0,   ! reference temperature (C)
     &   Q_10 = 1.7     ! factor for temperature dependence (non-dim)
     & )

!---------------------------------------------------------------------
!  DOM parameters for refractory components and DOP uptake
!---------------------------------------------------------------------

       real DOCrefract, DONrefract, DOPrefract
       parameter(
     &   DOCrefract = 0.3,                      ! fraction of DOC to refractory pool (Guo et al 2023 GRL)
     &   DONrefract = 0.3,                      ! fraction of DON to refractory pool
     &   DOPrefract = 0.3                       ! fraction of DOP to refractory pool
     & )

!---------------------------------------------------------------------
!  Threshold for PAR used in computation of pChl:
!  Introduced by CN in April 2015 (BEC blew up in SO setup otherwise)
!---------------------------------------------------------------------

       real PAR_thres_pChl
       parameter(
     &   PAR_thres_pChl = 1e-10
     & )

!---------------------------------------------------------------------
!  Thresholds below which denitrification will be reduced. If NO3 conc
!  is below the values set here, then the denitrification rate will be
!  multiplied by the inverse of the parameter value and by the NO3 conc.
!  This helps reduce negative concentrations somewhat. Introduced by
!  Cara Nissen in April 2015.
!---------------------------------------------------------------------

       real parm_denitrif_NO3_limit, parm_sed_denitrif_NO3_limit
       parameter(
     &   parm_denitrif_NO3_limit = 5.0,    ! threshold for reducing water column denitrification
     &   parm_sed_denitrif_NO3_limit = 5.0 ! threshold for reducing sediment denitrification
     & )

